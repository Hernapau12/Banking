from django.shortcuts import render
from .models import Deposit