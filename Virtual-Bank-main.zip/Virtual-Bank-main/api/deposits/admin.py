from django.contrib import admin
from .models import Deposit
# Register your models here.

admin.site.register(Deposit)