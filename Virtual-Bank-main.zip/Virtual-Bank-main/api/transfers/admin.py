from django.contrib import admin
from .models import Transfer
# Register your models here.

admin.site.register(Transfer)