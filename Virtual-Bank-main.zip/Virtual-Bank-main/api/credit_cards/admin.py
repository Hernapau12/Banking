from django.contrib import admin
from .models import CreditCard
# Register your models here.

admin.site.register(CreditCard)