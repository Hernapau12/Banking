Virtual Bank
Django - Djangorestframework - Bootstrap - Bash - Ansible - Docker - Nginx - PostgreSQL - MySQL - Redis - Ubuntu - JavaScript - CSS3 - HTML5
virtualbank.png
virtualbank.mp4
https://www.figma.com/design/SWDFbjEQyHLYsyq6uJixZp/Virtual_Bank?m=dev&node-id=833-2&t=g1WRxE1C3U0wVh7f-1