package com.webapp.bankingportal.config;

public class SwaggerConfig {

   
}
